"""lattice utilities."""
