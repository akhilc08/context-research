"""glacier utilities."""
