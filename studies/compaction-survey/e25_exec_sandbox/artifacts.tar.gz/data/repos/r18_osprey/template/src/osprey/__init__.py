"""osprey utilities."""
