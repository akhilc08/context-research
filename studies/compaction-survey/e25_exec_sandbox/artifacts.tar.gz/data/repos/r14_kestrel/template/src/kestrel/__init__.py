"""kestrel utilities."""
