"""quill utilities."""
