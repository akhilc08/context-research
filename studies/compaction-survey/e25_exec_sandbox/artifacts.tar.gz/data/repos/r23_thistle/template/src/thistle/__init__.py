"""thistle utilities."""
