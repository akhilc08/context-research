"""juniper utilities."""
