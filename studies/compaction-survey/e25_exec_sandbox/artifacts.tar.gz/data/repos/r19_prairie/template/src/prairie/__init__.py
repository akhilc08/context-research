"""prairie utilities."""
