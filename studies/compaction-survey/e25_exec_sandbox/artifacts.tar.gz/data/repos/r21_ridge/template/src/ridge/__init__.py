"""ridge utilities."""
