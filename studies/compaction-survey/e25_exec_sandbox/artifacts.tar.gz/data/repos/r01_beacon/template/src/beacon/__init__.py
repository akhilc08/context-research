"""beacon utilities."""
