"""quarry utilities."""
