"""fjord utilities."""
