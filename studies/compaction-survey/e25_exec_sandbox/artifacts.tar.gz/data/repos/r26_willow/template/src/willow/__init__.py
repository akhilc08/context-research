"""willow utilities."""
