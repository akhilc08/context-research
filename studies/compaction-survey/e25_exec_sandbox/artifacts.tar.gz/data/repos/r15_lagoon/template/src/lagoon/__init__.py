"""lagoon utilities."""
