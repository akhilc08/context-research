"""inlet utilities."""
