"""marlin utilities."""
